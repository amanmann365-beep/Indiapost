# Postal Address Finder Android V1.3

This package combines the Android client and the deployable Flask postal-search backend.

## Android client
Open this folder in Android Studio. The app supports camera/gallery OCR, Hindi/English text recognition, PIN extraction, ranked postal candidates, backend health testing, and India Post verification.

## Backend
See `postal-backend/README.md` and `DEPLOY/README_PRODUCTION.md`.

The Android app is not an APK in this archive. It is the Android Studio source project. Build it with a local Android SDK/Gradle environment.
