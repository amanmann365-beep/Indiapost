# Postal Address Finder — Android V1.1

This project is based on the ReleaseReady Android project and upgraded for field use.

## Features
- Native Android camera scan
- Gallery/photo input
- Google ML Kit OCR
- Editable OCR text before search
- 6-digit PIN extraction
- Online backend API integration
- Top-5 candidate offices
- Delivery status, office type, parent SO and confidence
- Google Maps search/navigation button
- Demo fallback when no backend URL is configured
- Backend URL saved locally on the device

## Production architecture
Android app → HTTPS API → current Department of Posts postal database.

Do not put the complete official database or database credentials inside the APK.
The server should import/version the current Department of Posts/OGD dataset and perform the postal matching.

Expected API:
GET /api/find?q=<urlencoded address>&pin=<optional>

Response example:
{
  "dataset_date":"2026-08",
  "matches":[
    {
      "office_name":"Example BO",
      "office_type":"Branch Post Office",
      "delivery":"Delivery Office",
      "pincode":"123456",
      "district":"Example District",
      "state":"Example State",
      "parent_so":"Example SO",
      "score":0.91,
      "confidence":"HIGH",
      "confidence_pct":91,
      "reason":["exact PIN","delivery office","locality/name similarity"]
    }
  ]
}

## Build
Open this folder in Android Studio, allow Gradle sync, then:
Build → Build APK(s).

The environment used to prepare this project does not contain the Android SDK/Gradle toolchain, so an APK has not been claimed as tested here.


## V1.2 field-ready improvements
- Persistent backend URL setting
- Backend health/connection test
- Manual OCR correction
- Ranked BO/SO candidates with confidence
- Map navigation action
- Demo fallback when backend is not configured

## Deployment
Deploy the V4/V5 Flask backend over HTTPS. In the app enter `https://YOUR-DOMAIN/api/find`, save it, then test the connection.


## V1.2.0
- Added bundled ML Kit Devanagari OCR alongside Latin OCR.
- Added direct official India Post verification button.
- Removed unused location permissions from the manifest.
- Version code 10 / version 1.2.0.

Google's current ML Kit Android documentation lists `com.google.mlkit:text-recognition-devanagari:16.0.1` for bundled Devanagari recognition, alongside the Latin recognizer.
