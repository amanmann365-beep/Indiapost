# Go-Live Checklist

- [ ] Create GitHub repository from this package.
- [ ] Deploy `postal-backend` using `render.yaml` or another Docker host.
- [ ] Create persistent `/data` storage.
- [ ] Import the current Department of Posts All India Pincode Directory.
- [ ] Confirm `/health` reports `dataset_loaded: true` and a non-zero row count.
- [ ] Test `/api/find?q=...&pin=...`.
- [ ] Set Android backend URL to the HTTPS `/api/find` endpoint.
- [ ] Run the Android debug build.
- [ ] Test: PIN present, no PIN, Hindi address, OCR correction, BO→SO relationship, and no-result handling.
- [ ] Verify uncertain results using the official India Post locator.
- [ ] Refresh the postal dataset monthly and update `POSTAL_DATASET_DATE`.
