package com.example.postaladdressfinder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors

private data class Office(
    val name:String,
    val pin:String,
    val type:String,
    val delivery:String,
    val district:String,
    val state:String,
    val parentSO:String,
    val confidence:String,
    val confidencePct:Int,
    val score:Double,
    val reasons:String
)

class MainActivity : AppCompatActivity() {
    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var result: LinearLayout
    private lateinit var apiUrl: EditText
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val hindiRecognizer = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
    private val executor = Executors.newSingleThreadExecutor()
    private var cameraUri: Uri? = null

    private val camera = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && cameraUri != null) {
            try { readAddress(InputImage.fromFilePath(this, cameraUri!!)) }
            catch (e: Exception) { status.text = "Could not read captured image: ${e.message}" }
        }
    }

    private val gallery = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try { readAddress(InputImage.fromFilePath(this, uri)) }
            catch (e: Exception) { status.text = "Could not read image: ${e.message}" }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(makeView())
    }

    private fun makeView(): ScrollView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        box.addView(TextView(this).apply {
            text = "📮 Postal Address Finder"
            textSize = 27f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = "Scan → OCR → postal matching → likely delivery BO / parent SO"
            textSize = 14f
            setPadding(0, 6, 0, 16)
        })

        val cameraButton = Button(this).apply {
            text = "📷  SCAN ADDRESS"
            textSize = 17f
            setOnClickListener { takePhoto() }
        }
        box.addView(cameraButton)

        val galleryButton = Button(this).apply {
            text = "🖼️  SELECT ADDRESS PHOTO"
            setOnClickListener { gallery.launch("image/*") }
        }
        box.addView(galleryButton)

        address = EditText(this).apply {
            hint = "OCR address appears here. Correct it before searching."
            minLines = 7
            gravity = Gravity.TOP
            setPadding(18, 18, 18, 18)
        }
        box.addView(address)

        val find = Button(this).apply {
            text = "🏤  FIND DELIVERY BO / SO"
            textSize = 16f
            setOnClickListener { findOffice(address.text.toString()) }
        }
        box.addView(find)

        val retry = Button(this).apply {
            text = "🔄  CLEAR / NEW ADDRESS"
            setOnClickListener {
                address.text.clear(); result.removeAllViews(); addMessage("No result yet.")
                status.text = "Ready."
            }
        }
        box.addView(retry)

        box.addView(TextView(this).apply { text = "Backend URL (optional)"; textSize = 13f; setPadding(0, 14, 0, 4) })
        apiUrl = EditText(this).apply {
            setText(getPreferences(MODE_PRIVATE).getString("api_url", "https://YOUR-DOMAIN.example/api/find"))
            hint = "https://your-server/api/find"
            singleLine = true
            setPadding(18, 12, 18, 12)
        }
        box.addView(apiUrl)
        box.addView(Button(this).apply {
            text = "💾  SAVE BACKEND URL"
            setOnClickListener {
                getPreferences(MODE_PRIVATE).edit().putString("api_url", apiUrl.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Backend URL saved", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply {
            text = "🔗  TEST CONNECTION"
            setOnClickListener { testBackend() }
        })
        box.addView(Button(this).apply {
            text = "🌐  VERIFY ON INDIA POST"
            setOnClickListener {
                val pin = Regex("\\b[1-9][0-9]{5}\\b").find(address.text.toString())?.value
                val u = if (pin != null) "https://www.indiapost.gov.in/locate-postoffice?pincode=$pin" else "https://www.indiapost.gov.in/locate-postoffice"
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
            }
        })

        status = TextView(this).apply { text = "Ready."; setPadding(0, 14, 0, 8) }
        box.addView(status)
        result = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(result)
        addMessage("No result yet.")

        box.addView(TextView(this).apply {
            text = "Important: PIN match alone does not prove the exact delivery jurisdiction. Low-confidence results must be verified against current Department of Posts data."
            textSize = 12f
            setPadding(0, 18, 0, 10)
        })

        return ScrollView(this).apply { addView(box) }
    }

    private fun testBackend() {
        val base = apiUrl.text.toString().trim()
        if (base.isBlank() || base.contains("YOUR-DOMAIN")) {
            status.text = "Enter your deployed backend URL first."
            return
        }
        status.text = "Testing backend…"
        executor.execute {
            try {
                val health = base.substringBeforeLast("/api/find").trimEnd('/') + "/health"
                val c = (URL(health).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 7000; readTimeout = 7000
                    setRequestProperty("Accept", "application/json")
                }
                val code = c.responseCode
                c.disconnect()
                runOnUiThread { status.text = if (code in 200..299) "✅ Backend connected successfully." else "⚠️ Backend responded with HTTP $code." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "❌ Connection failed: ${e.message}" }
            }
        }
    }

    private fun addMessage(text: String) {
        result.removeAllViews()
        result.addView(TextView(this).apply { this.text = text; textSize = 16f; setPadding(0, 8, 0, 16) })
    }

    private fun takePhoto() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 101); return
        }
        try {
            val file = File.createTempFile("postal_address_", ".jpg", cacheDir)
            cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            camera.launch(intent)
        } catch (e: Exception) {
            status.text = "Camera could not start: ${e.message}"
        }
    }

    private fun readAddress(image: InputImage) {
        status.text = "Reading English + Hindi address…"
        recognizer.process(image).addOnSuccessListener { latin ->
            hindiRecognizer.process(image).addOnSuccessListener { devanagari ->
                val combined = listOf(latin.text.trim(), devanagari.text.trim())
                    .filter { it.isNotBlank() }.distinct().joinToString("\n")
                address.setText(combined)
                val pin = Regex("\\b[1-9][0-9]{5}\\b").find(combined)?.value
                status.text = "OCR complete${if (pin != null) ". PIN detected: $pin" else ". No PIN detected"}. Correct/confirm the address, then search."
            }.addOnFailureListener {
                address.setText(latin.text.trim())
                status.text = "English OCR complete. Hindi OCR unavailable on this build."
            }
        }.addOnFailureListener { status.text = "OCR failed: ${it.message}" }
    }

    private fun readAddress(bitmap: Bitmap) = readAddress(InputImage.fromBitmap(bitmap, 0))

    private fun findOffice(text: String) {
        if (text.isBlank()) { status.text = "Scan or enter an address first."; return }
        val pin = Regex("\\b[1-9][0-9]{5}\\b").find(text)?.value
        val base = apiUrl.text.toString().trim()
        if (base.isBlank() || base.contains("YOUR-DOMAIN")) {
            showDemo(text, pin)
            return
        }
        status.text = "Searching postal database…"
        executor.execute {
            try {
                val sep = if (base.contains("?")) "&" else "?"
                val url = URL(base + sep + "q=" + URLEncoder.encode(text, "UTF-8") + if (pin != null) "&pin=$pin" else "")
                val c = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 10000; readTimeout = 15000
                    setRequestProperty("Accept", "application/json")
                }
                val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                val code = c.responseCode
                c.disconnect()
                if (code !in 200..299) throw IllegalStateException("HTTP $code: $body")
                val data = JSONObject(body)
                val arr = data.optJSONArray("matches") ?: JSONArray()
                val offices = (0 until arr.length()).map { parseOffice(arr.getJSONObject(it)) }
                runOnUiThread {
                    status.text = "Found ${offices.size} candidate(s). Dataset: ${data.optString("dataset_date", "unknown")}."
                    showOffices(offices, text)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Backend unavailable: ${e.message}"
                    showDemo(text, pin)
                }
            }
        }
    }

    private fun parseOffice(o: JSONObject): Office = Office(
        o.optString("office_name", o.optString("name")),
        o.optString("pincode", o.optString("pin")),
        o.optString("office_type", o.optString("type")),
        o.optString("delivery", "Unknown"),
        o.optString("district", ""),
        o.optString("state", ""),
        o.optString("parent_so", ""),
        o.optString("confidence", "LOW"),
        o.optInt("confidence_pct", (o.optDouble("score", 0.0) * 100).toInt()),
        o.optDouble("score", 0.0),
        o.optJSONArray("reason")?.let { a -> (0 until a.length()).joinToString("; ") { i -> a.optString(i) } } ?: ""
    )

    private fun showOffices(offices: List<Office>, query: String) {
        result.removeAllViews()
        if (offices.isEmpty()) { addMessage("No candidate office found. Correct the OCR text and try again."); return }
        offices.take(5).forEachIndexed { i, o -> addOfficeCard(o, i == 0) }
    }

    private fun addOfficeCard(o: Office, top: Boolean) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16) }
        val title = TextView(this).apply { text = if (top) "⭐ ${o.name}" else o.name; textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD) }
        card.addView(title)
        card.addView(TextView(this).apply {
            text = "${o.type} • ${o.delivery}\nPIN: ${o.pin}\n${o.district}, ${o.state}" + if (o.parentSO.isNotBlank()) "\nParent SO: ${o.parentSO}" else "" +
                    "\nConfidence: ${o.confidence} (${o.confidencePct}%)\nWhy: ${o.reasons}"
            textSize = 14f; setPadding(0, 8, 0, 6)
        })
        card.addView(Button(this).apply {
            text = "🗺️  OPEN IN MAP"
            setOnClickListener {
                val q = URLEncoder.encode("${o.name}, ${o.district}, ${o.state}, India", "UTF-8")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$q")))
            }
        })
        result.addView(card)
        result.addView(Space(this).apply { minimumHeight = 12 })
    }

    private fun showDemo(text: String, pin: String?) {
        if (pin == null) { addMessage("⚠️ No 6-digit PIN detected. Connect the official-data backend for locality/village matching."); return }
        val offices = listOf(
            Office("Anwali B.O","131409","Branch Post Office","Delivery","Sonipat","Haryana","Bhainswal Kalan SO","DEMO",70,.70,"exact PIN; delivery office"),
            Office("Giwana B.O","131409","Branch Post Office","Delivery","Sonipat","Haryana","Bhainswal Kalan SO","DEMO",68,.68,"exact PIN; delivery office"),
            Office("Bhainswal Kalan SO","131409","Sub Post Office","Delivery","Sonipat","Haryana","Sonipat HO","DEMO",65,.65,"exact PIN; delivery SO")
        ).filter { it.pin == pin }
        if (offices.isEmpty()) addMessage("PIN $pin not found in demo records. Connect the official-data backend.") else showOffices(offices, text)
    }

    override fun onDestroy() { executor.shutdownNow(); recognizer.close(); hindiRecognizer.close(); super.onDestroy() }
}
