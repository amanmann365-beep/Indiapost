CREATE TABLE IF NOT EXISTS offices (
 id INTEGER PRIMARY KEY,
 circlename TEXT, regionname TEXT, divisionname TEXT, officename TEXT,
 pincode TEXT, officetype TEXT, delivery TEXT, district TEXT,
 statename TEXT, parent_so TEXT
);
CREATE INDEX IF NOT EXISTS idx_pin ON offices(pincode);
CREATE INDEX IF NOT EXISTS idx_name ON offices(officename);
CREATE INDEX IF NOT EXISTS idx_district ON offices(district);
CREATE INDEX IF NOT EXISTS idx_state ON offices(statename);
CREATE TABLE IF NOT EXISTS dataset_meta (key TEXT PRIMARY KEY, value TEXT);
