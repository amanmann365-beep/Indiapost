# Postal Address Finder — Production Backend

## 1. Import the official Department of Posts CSV

Place the downloaded official postal-office CSV in this folder as `postal_offices.csv`, then run:

```bash
python import_official_csv.py postal_offices.csv
```

The importer creates `postal.db` and records dataset metadata.

## 2. Run locally with Gunicorn

```bash
pip install -r requirements.txt
export POSTAL_DB=/absolute/path/to/postal.db
./start_production.sh
```

Check:

```bash
curl http://127.0.0.1:8080/health
```

## 3. Run with Docker

```bash
docker compose up -d --build
```

Then test:

```bash
curl http://127.0.0.1:8080/health
```

## 4. Put HTTPS in front

Deploy the container behind an HTTPS reverse proxy/load balancer. Do not configure the Android production build with plain HTTP on the public internet.

## 5. Connect Android

Set the Android backend URL to:

`https://YOUR-DOMAIN/api/find`

The app's connection test uses the corresponding `/health` endpoint.

## 6. Refresh data

When the Department of Posts monthly dataset is updated, import the new CSV into a staging database, verify row count and sample offices, then replace the production database during a controlled restart.

## 7. Important jurisdiction rule

The matcher is a candidate-ranking system. A high score is not itself a legal/official declaration of delivery jurisdiction. Keep India Post's official locator available for final verification where required.
