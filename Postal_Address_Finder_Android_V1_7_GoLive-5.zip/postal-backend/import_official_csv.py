import csv, sqlite3, sys, datetime, os, shutil, tempfile

DB=os.environ.get("POSTAL_DB","postal.db")
CSV_FILE=sys.argv[1] if len(sys.argv)>1 else "postal_offices.csv"

def pick(row,*names):
    for n in names:
        if n in row and row[n] is not None: return row[n]
    return ""

if not os.path.exists(CSV_FILE):
    raise SystemExit(f"CSV not found: {CSV_FILE}")

backup=DB+".bak"
if os.path.exists(DB): shutil.copy2(DB, backup)
con=sqlite3.connect(DB)
try:
    con.executescript(open("schema.sql",encoding="utf8").read())
    con.execute("BEGIN")
    con.execute("DELETE FROM offices")
    count=0
    with open(CSV_FILE,encoding="utf-8-sig",newline="") as f:
        r=csv.DictReader(f)
        for row in r:
            con.execute("""INSERT INTO offices
            (circlename,regionname,divisionname,officename,pincode,officetype,
             delivery,district,statename,parent_so) VALUES(?,?,?,?,?,?,?,?,?,?)""",(
              pick(row,"circlename","Circle Name"), pick(row,"regionname","Region Name"),
              pick(row,"divisionname","Division Name"), pick(row,"officename","Office Name"),
              str(pick(row,"pincode","Pincode")).strip(), pick(row,"officetype","Office Type"),
              pick(row,"delivery","Delivery"), pick(row,"district","District"),
              pick(row,"statename","State Name","State"), pick(row,"parent_so","Parent SO")))
            count += 1
    if count == 0: raise RuntimeError("No rows imported; refusing to replace dataset")
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    con.execute("INSERT OR REPLACE INTO dataset_meta(key,value) VALUES('imported_at_utc',?)",(stamp,))
    con.execute("INSERT OR REPLACE INTO dataset_meta(key,value) VALUES('source_file',?)",(os.path.basename(CSV_FILE),))
    con.execute("INSERT OR REPLACE INTO dataset_meta(key,value) VALUES('row_count',?)",(str(count),))
    con.commit()
    print(f"Imported {count} postal-office records at {stamp}")
except Exception:
    con.rollback(); con.close()
    if os.path.exists(backup): shutil.copy2(backup, DB)
    raise
else:
    con.close()
