# Postal Finder Backend — Production V1.5

Uses the Department of Posts All India Pincode Directory as the primary postal dataset. The OGD catalogue says the data is monthly and includes Circle, Region, Division, Office Name, Pincode, Office Type, Delivery, District and State.

## Import
`python import_official_csv.py postal_offices.csv`

The importer refuses an empty dataset, keeps a `.bak` rollback copy, and records import timestamp/row count in `dataset_meta`.

## Run
`python backend_api.py`

`GET /health` returns API and dataset status.
`GET /api/find?q=<address>&pin=<6-digit-pin>` returns up to five ranked candidates.

No-PIN searches use indexed/token-derived SQL candidates instead of taking an arbitrary first 2,000 offices. PIN searches are exact first. The matcher then considers delivery status, office type, locality/name similarity and BO→parent-SO information.

## Production rules
- HTTPS only.
- Do not store scanned addresses unless explicitly required.
- Keep dataset backups and monthly refresh history.
- Do not represent a ranked candidate as legally/administratively confirmed postal jurisdiction; retain official India Post verification.
