from flask import Flask, request, jsonify
import sqlite3, os, re
from advanced_matcher import rank

DB=os.environ.get("POSTAL_DB","postal.db")
app=Flask(__name__)
API_KEY=os.environ.get('POSTAL_API_KEY','').strip()
ALLOWED_ORIGINS=os.environ.get('ALLOWED_ORIGINS','').strip()

def authorized():
    return (not API_KEY) or request.headers.get('X-API-Key','') == API_KEY

def add_cors(resp):
    origin=request.headers.get('Origin','')
    if ALLOWED_ORIGINS == '*' or (origin and origin in {x.strip() for x in ALLOWED_ORIGINS.split(',')}):
        resp.headers['Access-Control-Allow-Origin']=origin
        resp.headers['Vary']='Origin'
    return resp


def norm(s):
    s=(s or "").lower()
    return re.sub(r"[^a-z0-9\u0900-\u097f ]+"," ",s).strip()

def meta():
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    try:
        return {r["key"]:r["value"] for r in con.execute("SELECT key,value FROM dataset_meta")}
    except sqlite3.OperationalError: return {}
    finally: con.close()

def candidate_rows(q,pin):
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    try:
        if pin:
            cur=con.execute("SELECT * FROM offices WHERE pincode=? ORDER BY CASE WHEN lower(delivery) LIKE '%delivery%' THEN 0 ELSE 1 END, officename",(pin,))
            rows=cur.fetchall()
        else:
            toks=[t for t in norm(q).split() if len(t)>=3][:6]
            clauses=[]; args=[]
            for t in toks:
                like=f"%{t}%"
                clauses.append("(lower(officename) LIKE ? OR lower(district) LIKE ? OR lower(statename) LIKE ? OR lower(parent_so) LIKE ?)")
                args += [like,like,like,like]
            if clauses:
                rows=con.execute("SELECT * FROM offices WHERE " + " OR ".join(clauses) + " LIMIT 5000",args).fetchall()
            else:
                rows=con.execute("SELECT * FROM offices ORDER BY officename LIMIT 5000").fetchall()
        return [dict(r) for r in rows]
    finally: con.close()

@app.get('/api/find')
def find():
    if not authorized(): return add_cors(jsonify({'error':'unauthorized'})),401
    q=request.args.get('q','').strip(); pin=request.args.get('pin','').strip()
    if not q and not pin: return jsonify({'error':'q or pin is required'}),400
    candidates=candidate_rows(q,pin)
    matches=rank(q,candidates,pin)[:5]
    m=meta()
    return add_cors(jsonify({'dataset_date':os.environ.get('POSTAL_DATASET_DATE',m.get('imported_at_utc','unknown')),
                    'dataset_rows':m.get('row_count'),'matches':matches}))

@app.get('/health')
def health():
    m=meta();
    return add_cors(jsonify({'ok':True,'dataset_loaded':bool(m.get('row_count')), 'dataset_rows':m.get('row_count'),'dataset_imported_at':m.get('imported_at_utc')}))

if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',8080)))
