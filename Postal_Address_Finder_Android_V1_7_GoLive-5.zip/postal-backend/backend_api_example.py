# Minimal reference API shape (Flask-style pseudocode)
# Connect this to your official Department of Posts dataset.
#
# GET /api/find?q=<ocr text>&pin=<optional>
# Return:
# {
#   "dataset_date": "YYYY-MM-DD",
#   "matches": [
#      {
#        "office_name": "...",
#        "office_type": "Branch Post Office",
#        "delivery": "Delivery Office",
#        "pincode": "......",
#        "district": "...",
#        "state": "...",
#        "parent_so": "...",
#        "score": 0.94,
#        "reason": ["exact PIN", "delivery office", "locality match"]
#      }
#   ]
# }
#
# Do not expose database credentials in the browser.
