import re
from difflib import SequenceMatcher

# Lightweight normalization for Indian address OCR.
# Production can replace transliteration with a dedicated Indic NLP model.

DEV_TO_LATIN = {
 "गांव":"gaon","गाँव":"gaon","ग्राम":"gram","पोस्ट":"post","डाक":"dak",
 "थाना":"thana","तहसील":"tehsil","जिला":"district","जिलाः":"district",
 "रोड":"road","सड़क":"sadak","मोहल्ला":"mohalla","नगर":"nagar",
 "कॉलोनी":"colony","कॉलोनी":"colony","ब्लॉक":"block","वार्ड":"ward",
 "सो":"so","बीओ":"bo","एचओ":"ho"
}
def norm(s):
    s=(s or "").lower().strip()
    for a,b in DEV_TO_LATIN.items(): s=s.replace(a,b)
    s=re.sub(r"[^a-z0-9\u0900-\u097f ]+"," ",s)
    return re.sub(r"\s+"," ",s)

def words(s):
    return {x for x in norm(s).split() if len(x)>=2}

def token_score(a,b):
    A,B=words(a),words(b)
    if not A or not B:return 0
    return len(A&B)/max(len(A),len(B))

def confidence(score, gap=0):
    # Conservative bands: avoid presenting weak guesses as certainty.
    if score>=.86 and gap>=.08:return ("HIGH",round(score*100))
    if score>=.68 and gap>=.04:return ("MEDIUM",round(score*100))
    return ("LOW",round(score*100))

def rank(query, rows, pin=None):
    out=[]
    for r in rows:
        office=" ".join(str(r.get(k,"")) for k in
          ["officename","district","statename","villagename","localbody"])
        sim=token_score(query,office)
        exact=bool(pin and str(r.get("pincode",""))==pin)
        delivery="delivery" in norm(r.get("delivery",""))
        typ=norm(r.get("officetype",""))
        score=.58 if exact else 0
        if delivery: score+=.18
        if "branch" in typ: score+=.08
        elif "sub" in typ: score+=.07
        score+=min(sim,.55)*.30
        out.append((score,r,sim,exact,delivery))
    out.sort(key=lambda x:x[0],reverse=True)
    ranked=[]
    for i,(score,r,sim,exact,delivery) in enumerate(out[:5]):
        gap=score-out[1][0] if i==0 and len(out)>1 else 0
        band,pct=confidence(min(score,.99),gap)
        reasons=[]
        if exact: reasons.append("exact PIN")
        if delivery: reasons.append("delivery office")
        if sim>=.15: reasons.append("locality/name similarity")
        if r.get("parent_so"): reasons.append("BO→parent SO available")
        ranked.append({"office_name":r.get("officename"),
          "office_type":r.get("officetype"),"delivery":r.get("delivery"),
          "pincode":r.get("pincode"),"district":r.get("district"),
          "state":r.get("statename"),"parent_so":r.get("parent_so"),
          "score":round(min(score,.99),3),"confidence":band,
          "confidence_pct":pct,"reason":reasons})
    return ranked
