# Deploy the Postal Address Finder backend on Render

1. Push this repository to GitHub.
2. In Render, create a new Blueprint and select the repository.
3. Render will use `postal-backend/render.yaml` and the Dockerfile.
4. After deployment, check `/health`.
5. Import the current Department of Posts pincode dataset into `postal.db` before using the API in production.
6. Set `POSTAL_DATASET_DATE` to the source dataset month/date.
7. Use the generated HTTPS service URL as the Android backend URL, ending in `/api/find`.

Important: the deployment does not invent or scrape postal jurisdiction. The database must be populated from the Department of Posts/OGD dataset and refreshed monthly.
