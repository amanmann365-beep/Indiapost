#!/bin/sh
set -eu
: "${PORT:=8080}"
: "${POSTAL_DB:=/data/postal.db}"
exec gunicorn --bind "0.0.0.0:${PORT}" --workers 2 --threads 4 --timeout 60 backend_api:app
