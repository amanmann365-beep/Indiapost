const $=id=>document.getElementById(id);
const camera=$("camera"), canvas=$("canvas"), preview=$("preview"), ocr=$("ocr"), status=$("status"), result=$("result");
let stream=null, lastImage=null;

function setStatus(t,error=false){status.textContent=t;status.className="status"+(error?" error":"");}
function normalize(s){return (s||"").toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}\s]/gu," ").replace(/\s+/g," ").trim();}
function pins(s){return [...new Set((s||"").match(/\b[1-9][0-9]{5}\b/g)||[])];}
function tokens(s){return new Set(normalize(s).split(/\s+/).filter(x=>x.length>=3));}
function similarity(a,b){
  const A=tokens(a),B=tokens(b); if(!A.size||!B.size)return 0;
  let hit=0; for(const x of A) if(B.has(x))hit++;
  return hit/Math.max(A.size,B.size);
}
function officeTypeRank(x){return /branch/i.test(x)?3:/sub/i.test(x)?2:/head/i.test(x)?1:0}
function render(offices, pin, query){
  if(!offices.length){result.innerHTML="<div class='result empty'>No matching office found. Try correcting the OCR text or enter the PIN clearly.</div>";return}
  result.innerHTML=offices.slice(0,5).map((o,i)=>`
    <div class="office ${i===0?'top':''}">
      <h3>${escapeHtml(o.name)}</h3>
      <span class="tag">${escapeHtml(o.type||"Post Office")}</span>
      <span class="tag ${String(o.delivery).toLowerCase().includes("non")?'warn':''}">${escapeHtml(o.delivery||"Delivery status unknown")}</span> <span class="tag">${escapeHtml(o.confidence||"")}${o.confidence_pct?` ${o.confidence_pct}%`:""}</span>
      <div class="meta"><b>PIN:</b> ${escapeHtml(o.pin||pin||"—")}<br>
      <b>District:</b> ${escapeHtml(o.district||"—")}<br>
      <b>State:</b> ${escapeHtml(o.state||"—")}<br>
      ${o.parentSO?`<b>Parent SO:</b> ${escapeHtml(o.parentSO)}<br>`:""}
      ${o.reason?`<b>Why matched:</b> ${escapeHtml(o.reason)}`:""}</div>
      <div class="score">Match score: ${Math.round(o.score||0)}%</div>
    </div>`).join("");
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

async function doOCR(blob){
  setStatus("Reading address…");
  const {data:{text}}=await Tesseract.recognize(blob,"eng",{logger:m=>{
    if(m.status&&m.progress) setStatus(`OCR: ${m.status} ${Math.round(m.progress*100)}%`);
  }});
  ocr.value=text.trim();
  setStatus(`OCR complete. Detected PIN(s): ${pins(text).join(", ")||"none"}. Correct the text if needed.`);
}

$("startCamera").onclick=async()=>{
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1920}},audio:false});
    camera.srcObject=stream; camera.hidden=false; $("capture").disabled=false; setStatus("Camera ready.");
  }catch(e){setStatus("Camera could not open. Use HTTPS or choose a photo instead.",true)}
};
$("capture").onclick=async()=>{
  if(!stream)return;
  canvas.width=camera.videoWidth;canvas.height=camera.videoHeight;
  canvas.getContext("2d").drawImage(camera,0,0);
  canvas.toBlob(async b=>{lastImage=b;preview.src=URL.createObjectURL(b);preview.hidden=false;await doOCR(b)},"image/jpeg",.92);
};
$("file").onchange=async e=>{
  const f=e.target.files[0];if(!f)return;lastImage=f;preview.src=URL.createObjectURL(f);preview.hidden=false;await doOCR(f);
};
$("readAgain").onclick=async()=>{if(lastImage)await doOCR(lastImage);else setStatus("First capture or choose an image.",true)};

$("find").onclick=async()=>{
  const q=ocr.value.trim(); const ps=pins(q);
  if(!q){setStatus("Enter or scan an address first.",true);return}
  setStatus("Searching the postal database…");
  try{
    const params=new URLSearchParams({q});
    if(ps[0]) params.set("pin",ps[0]);
    const r=await fetch(`/api/find?${params.toString()}`);
    if(!r.ok) throw new Error("API "+r.status);
    const data=await r.json();
    const ranked=(data.matches||[]).map(x=>({
      name:x.office_name||x.name,
      pin:x.pincode||x.pin,
      type:x.office_type||x.type,
      delivery:x.delivery,
      district:x.district,
      state:x.state,
      parentSO:x.parent_so,
      score:(x.score||0)*100,
      reason:(x.reason||[]).join("; ")
    }));
    render(ranked,ps[0],q);
    setStatus(`Found ${ranked.length} candidate(s). Dataset: ${data.dataset_date||"current backend data"}.`);
  }catch(e){
    setStatus("Postal database backend is not connected. For a demo, enter a PIN and use the V3 prototype.",true);
    result.innerHTML="<div class='result empty'>Backend not connected. Deploy the included API service and import the current official postal dataset.</div>";
  }
};
