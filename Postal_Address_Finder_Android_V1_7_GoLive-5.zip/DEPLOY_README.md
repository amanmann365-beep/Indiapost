# Postal Address Finder — Production Integration V1.3

## Architecture
- Android app: OCR, Hindi/English address editing, PIN extraction, API search.
- Flask backend: `/api/find` and `/health`.
- SQLite: imported Department of Posts postal-office data.
- Official verification: India Post Locate Post Office.

## Official data
Use the Department of Posts All India Pincode Directory available through the Government of India OGD Platform. The catalogue states that the dataset is monthly and contains Circle, Region, Division, Office Name, Pincode, Office Type, Delivery, District and State.

## Import
1. Obtain the current official export/API response.
2. Save it as `postal_offices.csv` in this backend directory.
3. Run:
   `python import_official_csv.py postal_offices.csv`
4. Start:
   `python backend_api.py`
5. Verify:
   `http://127.0.0.1:5000/health`

## Android
Set the backend URL to the HTTPS production endpoint ending in `/api/find`, for example:
`https://YOUR-DOMAIN.example/api/find`

Then use TEST CONNECTION. Do not use HTTP in production.

## Important postal-jurisdiction rule
The app ranks candidates; it must not claim that geographical proximity alone establishes delivery jurisdiction. PIN, office delivery status, office type, locality/name evidence and parent-office relationships are weighted first. Official India Post verification remains available from the result screen.

## Production hardening checklist
- HTTPS only
- Restrict CORS to known clients if web frontend is deployed
- Add API rate limiting
- Keep a dataset version/date in the database
- Preserve the previous dataset for rollback
- Log only operational metadata; avoid storing scanned personal addresses by default
- Schedule monthly dataset refresh
- Add authenticated/admin-only data import endpoint if imports are exposed remotely
