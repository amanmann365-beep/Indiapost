# Postal Address Finder Android V1.5

Production-hardening release focused on reliable postal candidate retrieval.

### What changed
1. Backend no-PIN search no longer depends on an arbitrary first-2,000-row sample.
2. Exact PIN searches use indexed lookup.
3. Dataset metadata records import timestamp and row count.
4. Imports are transactional and keep a rollback `.bak` copy.
5. `/health` reports dataset status.
6. Android remains Hindi/English OCR + manual correction + PIN extraction + ranked BO/SO results + official India Post verification.

### Official data workflow
Download the current Department of Posts All India Pincode Directory from the Government of India OGD catalogue, save the export as `postal_offices.csv`, then run the backend importer.

### Important
This source package is not an APK. An Android SDK/Gradle environment is required to compile and sign the APK.
