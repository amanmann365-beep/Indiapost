# Postal Address Finder — Android V1.4

Production-hardening update over V1.3.

## Changes
- Full-resolution camera capture via FileProvider instead of the low-resolution camera thumbnail.
- Hindi/Devanagari + Latin OCR retained.
- HTTP error responses are now handled explicitly instead of attempting to parse them as success JSON.
- Version 1.4.0 / versionCode 11.
- Official-data backend remains the production source of postal jurisdiction.

## Data model
Use the Department of Posts All India Pincode Directory as the authoritative postal office dataset. Keep BO→SO relationships from current postal data. Use locality/LGD data only for candidate generation where PIN is absent.

## Important
This source package is not an APK. An APK requires a working Android SDK/Gradle environment. After building, test camera, both OCR scripts, PIN extraction, backend search, no-PIN search, and India Post verification on a physical Android device.
