# APK build status — V1.5

The source project is prepared for compilation.

This execution environment does not contain Android SDK, Gradle or ADB, so an APK cannot be truthfully claimed as locally compiled/tested here.

A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`. It builds `app-debug.apk` automatically and uploads it as a workflow artifact.
