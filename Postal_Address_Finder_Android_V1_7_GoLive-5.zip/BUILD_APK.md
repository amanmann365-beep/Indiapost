# Build the APK

## Fastest route — GitHub Actions

1. Create an empty GitHub repository.
2. Upload this project folder, preserving `.github/workflows/android-apk.yml`.
3. Open **Actions → Build Android APK → Run workflow**.
4. When the workflow completes, open the run and download the artifact:
   `postal-address-finder-debug-apk`.
5. Install the APK on an Android device for field testing.

The workflow installs Java 21 and Gradle 8.10.2 and runs `:app:assembleDebug` on GitHub's Android-capable Linux runner.

## Local build

Requires Android SDK (API 35), Java 21 and Gradle 8.10.2.

```bash
gradle :app:assembleDebug
```

Output:

`app/build/outputs/apk/debug/app-debug.apk`

## Release signing

The debug APK is for testing. For a distributable release APK, configure a private Android signing keystore and Gradle signing configuration. Never commit the keystore or passwords to the repository.
